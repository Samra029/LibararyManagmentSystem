#!/bin/env python
"""
This script runs the Library_Management_System application using a development server.
"""

import os
from Library_Management_System import app as application
from Library_Management_System import db
from Library_Management_System.views import main

# Register blueprint
application.register_blueprint(main)

if __name__ == "__main__":
    # ✅ Create database tables inside the app context
    with application.app_context():
        db.create_all()
    
    # Server host and port setup
    HOST = os.environ.get("SERVER_HOST", "localhost")
    try:
        PORT = int(os.environ.get("SERVER_PORT", "5555"))
    except ValueError:
        PORT = 5555
    
    # Run the application
    application.run(host=HOST, port=PORT, threaded=True, debug=True)

